{% if item.override_background_color is empty %}
{% else %} 
	#{{item.item_id}} .ue_timeline_item_content_main{
      background-color:{{item.override_background_color}};
    } 
{% endif %}	


{% if item.override_pointer_color is empty %}
{% else %} 
	#{{item.item_id}} .ue_timeline_item_pointer_inside{
      background-color:{{item.override_pointer_color}};
    } 
{% endif %}


{% if item.override_icon_bg is empty %}
{% else %} 
	#{{item.item_id}} .ue_timeline_item_icon_holder{
      background-color:{{item.override_icon_bg}};
    } 
{% endif %}