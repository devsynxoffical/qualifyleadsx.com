<div id="{{uc_id}}" class="uc-items-wrapper{{uc_filtering_addclass}}{{remote_parent.class}} {{uc_dynamic_popup_class}}" {{uc_filtering_attributes|raw}} {{remote_parent.attributes|raw}}>
  {{put_items()}} 
</div>