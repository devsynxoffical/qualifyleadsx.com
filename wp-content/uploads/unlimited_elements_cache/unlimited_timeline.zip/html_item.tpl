{# twig vars #}{##}
{% set subTitleElem %}
  <div class="ue_timeline_item_subtitle" >{{item.subtitle|raw}}</div>
{% endset %}
{# end twig vars #}{##}

<div class="ue_timeline_item {{item.item_repeater_class}} " id="{{item.item_id}}">
    <div class="ue_timeline_item_content">
      
      <div class="ue_timeline_item_content_main">
        
        {% if show_image == "true" %}
          {% if image_link == "true" and item.image_link == "true" %}<a href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>{% endif %}
              <img class="ue_timeline_item_image" src="{{item.image}}" {{item.image_attributes|raw}}>
          {% if image_link == "true" and item.image_link == "true" %}</a>{% endif %}
        {% endif %}
        
        <div class="ue_timeline_item_content_inside">
        {% if show_sub_title == "before_title" %}{{subTitleElem}}{% endif %}
        {% if show_title == "true" %}<div class="ue_timeline_item_title" >{{item.title|raw}}</div>{% endif %}
        {% if show_sub_title == "after_title" %}{{subTitleElem}}{% endif %}
        {% if show_text == "true" %}<div class="ue_timeline_item_text">{{item.text|raw}}</div>{% endif %}	
      	{% if show_sub_title == "after_text" %}{{subTitleElem}}{% endif %}
        {% if show_button == "true" %}
          
          <div class="ue_timeline_item_button">
            {% if multisource != "uc_items" %}
              <a class="ue_timeline_item_link {{item.dynamic_popup_link_class|raw}}" {{item.dynamic_popup_link_attributes|raw}} href="{{item.link|raw}}">{% if item.button_text is not empty %}{{item.button_text|raw}}{% else %}{{button_text|raw}}{% endif %}</a>
            {% else %}
            	<a class="ue_timeline_item_link" href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>{% if item.button_text is not empty %}{{item.button_text|raw}}{% else %}{{button_text|raw}}{% endif %}</a>
            {% endif %}
          </div>
          
        {% endif %}  
        </div>
        {% if content_box_link == "true" %}<a class="ue_timeline_item_content_main_link" href="{{item.link|raw}}" {{item.link_html_attributes|raw}}></a>{% endif %}
      </div>
      
      {% if show_pointer == "true" %}
      <div class="ue_timeline_item_pointer">
        <div class="ue_timeline_item_pointer_inside"></div>
      </div>
      {% endif %}
      
      <div class="ue_timeline_item_pointer_spacer"></div>
      
    </div>
  
    <div class="ue_timeline_item_icon">
      <div class="ue_timeline_item_icon_line_offset">
      	<div class="ue_timeline_item_icon_line_offset_mask ue_timeline_item_line_icon_holder">
          <div class="ue_timeline_item_line_floating_icon-offset ue_timeline_floating_icon">{{floating_icon_html|raw}}</div>
        </div>
      </div>
      <div class="ue_timeline_item_icon_holder">
        {% if icon_source == "icon" %}{{item.icon_html|raw}}{% endif %}
        {% if icon_source == "same_icon" %}{{icon_for_all_html|raw}}{% endif %}
        {% if icon_source == "image" %}<img src="{{item.icon_image}}" class="ue_timeline_item_icon_image" {{item.icon_image_attributes|raw}}>{% endif %}
        {% if icon_source == "text" %}
             <div class="ue_text_one">{{item.text_one|raw}}</div>
             <div class="ue_text_two">{{item.text_two|raw}}</div>
             <div class="ue_text_three">{{item.text_three|raw}}</div>
        {% endif %}
      </div>
      
      <div class="ue_timeline_item_icon_line">
      	<div class="ue_timeline_item_icon_line_mask ue_timeline_item_line_icon_holder">
          <div class="ue_timeline_item_line_floating_icon ue_timeline_floating_icon">{{floating_icon_html|raw}}</div>
        </div>
      </div>
      
    </div>
    <div class="ue_timeline_item_spacer">
      {% if show_opposite_image == "true" %}
      <div class="ue_timeline_item_img_wrapper">
        <img class="uet_opposite_img" src="{{item.opposite_image}}" alt="{{item.opposite_image_alt}}" title="{{item.opposite_image_title}}">
      </div>
      {% endif %}
  	</div>
  </div>